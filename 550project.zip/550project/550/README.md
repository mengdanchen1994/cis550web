# NodeApp

Current issues:

1. It could render the person page now, but still cannot get the data, querying the data path directly works.
1. clean code
